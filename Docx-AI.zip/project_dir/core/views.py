from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import UserRegistrationForm, SymptomEntryForm
from .models import SymptomEntry

# Helper function to generate suggestions based on severity
def get_suggestion_by_severity(severity):
    """
    Generate predefined suggestions based on severity level.
    This is a simple rule-based system - no AI/ML.
    """
    suggestions = {
        'Low': "Home rest recommended. Stay hydrated, get adequate sleep, and monitor your symptoms. If symptoms persist for more than 3 days, consider consulting a doctor.",
        'Medium': "Rest and basic self-care advised. Consider over-the-counter medications if appropriate. Monitor symptoms closely. If symptoms worsen or persist for more than 2 days, schedule a doctor visit.",
        'High': "Immediate medical consultation strongly recommended. Please contact a healthcare professional as soon as possible. For emergencies, visit the nearest hospital or call emergency services."
    }
    return suggestions.get(severity, suggestions['Low'])

def signup_view(request):
    """
    User registration/signup view.
    """
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, f'Account created successfully for {user.username}! Please login.')
            return redirect('login')
    else:
        form = UserRegistrationForm()
    
    return render(request, 'core/signup.html', {'form': form})

@login_required
def profile_view(request):
    """
    User profile page showing account information.
    """
    return render(request, 'core/profile.html', {'user': request.user})

@login_required
def dashboard_view(request):
    """
    Main dashboard after login.
    Shows welcome message and quick access to features.
    """
    # Get recent symptom entries (last 5)
    recent_symptoms = SymptomEntry.objects.filter(user=request.user)[:5]
    
    context = {
        'recent_symptoms': recent_symptoms,
    }
    return render(request, 'core/dashboard.html', context)

@login_required
def add_symptom_view(request):
    """
    View to add new symptom entry.
    """
    if request.method == 'POST':
        form = SymptomEntryForm(request.POST)
        if form.is_valid():
            symptom_entry = form.save(commit=False)
            symptom_entry.user = request.user
            # Generate suggestion based on severity
            symptom_entry.suggestion = get_suggestion_by_severity(symptom_entry.severity)
            symptom_entry.save()
            messages.success(request, 'Symptom entry saved successfully!')
            return redirect('symptom_history')
    else:
        form = SymptomEntryForm()
    
    return render(request, 'core/add_symptom.html', {'form': form})

@login_required
def symptom_history_view(request):
    """
    View to display all symptom entries for the logged-in user.
    """
    symptoms = SymptomEntry.objects.filter(user=request.user)
    return render(request, 'core/symptom_history.html', {'symptoms': symptoms})

@login_required
def health_tips_view(request):
    """
    Static health tips page.
    """
    return render(request, 'core/health_tips.html')

@login_required
def doctor_contact_view(request):
    """
    Doctor contact/telemedicine page with doctor listings.
    """
    # Sample doctor data - in a real app, this would come from a database
    doctors = [
        {
            'name': 'Dr. Sarah Johnson',
            'specialization': 'General Physician',
            'phone': '+1-555-0101',
            'whatsapp': 'https://wa.me/15550101',
            'meet_link': 'https://meet.google.com/abc-defg-hij'
        },
        {
            'name': 'Dr. Michael Chen',
            'specialization': 'Cardiologist',
            'phone': '+1-555-0102',
            'whatsapp': 'https://wa.me/15550102',
            'meet_link': 'https://meet.google.com/xyz-wuvt-rst'
        },
        {
            'name': 'Dr. Emily Rodriguez',
            'specialization': 'Pediatrician',
            'phone': '+1-555-0103',
            'whatsapp': 'https://wa.me/15550103',
            'meet_link': 'https://meet.google.com/mno-pqrs-tuv'
        },
        {
            'name': 'Dr. James Wilson',
            'specialization': 'Dermatologist',
            'phone': '+1-555-0104',
            'whatsapp': 'https://wa.me/15550104',
            'meet_link': 'https://meet.google.com/ghi-jklm-nop'
        },
        {
            'name': 'Dr. Lisa Anderson',
            'specialization': 'Neurologist',
            'phone': '+1-555-0105',
            'whatsapp': 'https://wa.me/15550105',
            'meet_link': 'https://meet.google.com/qrs-tuvw-xyz'
        },
    ]
    
    return render(request, 'core/doctor_contact.html', {'doctors': doctors})
